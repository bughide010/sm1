// index.js - fallback that loads src/inject.js
console.log("index.js loaded; delegating to src/inject.js");
require('./src/inject.js');
